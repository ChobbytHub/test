// JavaScript Document$(function(){
    $.when(
        // html作成
        $.getJSON("data.json" , function(data) {
            for(var i in data){
                $(".photo-list").append(
					'<li>' +
						data[i].name +
					'</li>' +
					'<a class="photo js-modal-open" data-target="modal' + data[i].id + '" href="#">詳細A</a>'
				);
				// モーダル生成
                $(".modal-area").append(
					'<article id="modal' + data[i].id +'" class="modal js-modal is_close">' +
						'<div class="modal-bg js-modal-close"></div>' +
						'<div class="modal-content">' +
							'<div class="modal-inner">' +
								'<div class="modal-item">' +
									'<div class="modal-photo">' +
										'<img src="' + data[i].img + '">' +
									'</div>' +
								'<p>' + data[i].name + '</p>' +
								'<p>' + data[i].qualification + '</p>' +
								'<p>' + data[i].category + '</p>' +
								'</div>' +
							'</div>' +
						'<div class="btn-close js-modal-close">close</div>' +
						'</div>' +
					'</article>'
				);
            }
        })
    ).done(function() {
        // モーダル動作
        var scrollPos;
        console.log($('.photo-list'));
        $('.js-modal-open').each(function(){
            $(this).on('click',function(){
                scrollPos = $(window).scrollTop();
                var target = $(this).data('target');
                var modal = document.getElementById(target);
                $(modal).addClass('is_open').removeClass('is_close');
                $('body').addClass('fixed').css({'top':-scrollPos});
                return false;
            });
        });
        $('.js-modal-close').on('click',function(){
            $('.js-modal').addClass('is_close').removeClass('is_open');
            $('body').removeClass('fixed').css({'top':''});
            $(window).scrollTop(scrollPos);
            return false;
        });
    }).fail(function() {
		// エラーが発生したときの処理
        console.log('エラー');
	});
