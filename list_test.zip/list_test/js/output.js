$(function jsonOutput(){
  // XMLHttpRequestインスタンスを作成
  let request = new XMLHttpRequest();

  // JSONファイルが置いてあるパスを記述
  request.open('GET', './output.json');
  request.send();

  // JSON読み込み時の処理
  request.onreadystatechange = () => {
    // 全てのデータを受信・正常に処理された場合
    if (request.readyState == 4 && request.status == 200) {
      // JSONデータを変換
      let json = JSON.parse(request.responseText);

      // 生成したHTMLを入れておく変数
      let html = '';
      // 生成したモーダル用のHTMLを入れておく変数
      let modal = '';

      // JSONにあるオブジェクト数の分だけfor文で処理
      for (let i = 0; i < json.length; i++) {
        // ポップアップ表示の場合
          let htmlParts =
					


           '<li class="test">' +
            json[i].title +
           '</li><a href="#">表示</a>';





					
	          // 先述の変数の中に、出来上がったHTMLを格納
          html += htmlParts;				
    };



      // 変数に格納したHTMLを出力
      document.getElementById('sample').innerHTML = html;
    };
  };
});
